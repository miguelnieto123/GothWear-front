import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export interface UserModule {
  id_user: number;
  username: string;
  email: string;
  userpassword?: string; 
  status?: string;
  register_date?: Date;
  id_rol?: number;

  role?: Role;
}

