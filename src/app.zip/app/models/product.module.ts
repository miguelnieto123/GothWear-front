import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export interface ProductModule {
  id_product: number;
  productname: string;
  productdescription?: string;
  price: number;
  stock: number;
  status: boolean;
}
