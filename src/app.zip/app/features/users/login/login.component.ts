import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { LoginRequest } from '../../models/user.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  form: LoginRequest = { email: '', userpassword: '' };
  error = '';
  loading = false;

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit(): void {
    if (!this.form.email || !this.form.userpassword) {
      this.error = 'Por favor completa todos los campos.';
      return;
    }
    this.loading = true;
    this.error = '';
    this.authService.login(this.form).subscribe({
      next: () => {
        this.loading = false;
        this.router.navigate(['/products']);
      },
      error: () => {
        this.loading = false;
        this.error = 'Credenciales incorrectas. Inténtalo de nuevo.';
      }
    });
  }
}
